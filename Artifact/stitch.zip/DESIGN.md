# Design System Strategy: The Curated Wanderer

## 1. Overview & Creative North Star
This design system moves away from the "utility-first" look of standard travel apps to embrace a **"Digital Editorial"** aesthetic. Our Creative North Star is **The Modern Naturalist**: a visual language that feels as tactile as a premium travel magazine but as fluid as a modern interface.

To break the "template" feel, we reject rigid, boxed grids in favor of **Intentional Asymmetry**. We use overlapping elements—such as a destination image breaking the bounds of a container—and high-contrast typography scales to create a sense of adventure. This system must feel safe enough for a family planning a retreat, yet energetic enough for a group of friends booking a road trip. We achieve this versatility through **Tonal Depth** rather than decorative clutter.

---

## 2. Colors & Signature Textures
Our palette is a sophisticated blend of forest greens (`primary`), sun-baked oranges (`secondary`), and ochre highlights (`tertiary`).

### The "No-Line" Rule
**Borders are prohibited for sectioning.** To define boundaries, use background color shifts. A `surface-container-low` card sitting on a `surface` background provides all the definition needed. If a section feels "lost," increase the tonal contrast between the containers rather than reaching for a stroke.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of organic materials. 
- **Base Layer:** `surface` (#f5f7f5)
- **Secondary Content Areas:** `surface-container` (#e6e9e7)
- **Interactive Elements/Cards:** `surface-container-lowest` (#ffffff) for maximum "lift."
- **Deep Inset Sections:** `surface-dim` (#d1d5d3) for utility footers or subtle sidebars.

### The Glass & Gradient Rule
To inject "soul" into the interface:
- **Glassmorphism:** For floating navigation bars or quick-action menus, use `surface` at 80% opacity with a `backdrop-filter: blur(20px)`. This allows travel photography to bleed through the UI, creating an immersive feel.
- **Signature Gradients:** For primary CTAs and Hero headers, use a subtle linear gradient from `primary` (#29664c) to `primary_dim` (#1b5a40) at a 135-degree angle. This prevents the "flat" look and adds a premium, satin-like finish.

---

## 3. Typography
We utilize a dual-typeface system to balance adventurous spirit with high-utility legibility.

*   **Display & Headlines (Plus Jakarta Sans):** A modern sans-serif with wide apertures. Use `display-lg` (3.5rem) for hero titles to create an editorial impact. The generous x-height feels "friendly" but professional.
*   **Body & Labels (Be Vietnam Pro):** Chosen for its exceptional legibility on-the-go. 
    *   **Hierarchy Tip:** Use `title-lg` for card headers and `body-md` for descriptions. 
    *   **Intentional Contrast:** Pair a `headline-sm` title with a `label-md` in all-caps (tracking +5%) for a sophisticated, "curated" look.

---

## 4. Elevation & Depth
In this system, depth is earned through light and shadow, not lines.

*   **The Layering Principle:** Avoid shadows where tonal shifts work. A `surface-container-highest` button on a `surface` background is sufficient for visibility.
*   **Ambient Shadows:** When an element must float (like a "Book Now" FAB), use a shadow color tinted with the `on-surface` hue: `rgba(44, 47, 46, 0.06)` with a `40px` blur and `12px` Y-offset. This mimics natural sunlight on a trail.
*   **The "Ghost Border" Fallback:** If accessibility requires a border (e.g., in high-glare outdoor use), use `outline-variant` at **15% opacity**. It should be felt, not seen.
*   **Roundedness:** Stick to the `md` (1.5rem) for standard cards and `full` (9999px) for interactive chips. This "softness" makes the app feel approachable and "friendly."

---

## 5. Components

### Buttons
- **Primary:** Gradient (`primary` to `primary_dim`), `full` roundedness. Text should be `on_primary_fixed`.
- **Secondary:** `secondary_container` background with `on_secondary_container` text. No border.
- **Tertiary:** Transparent background, `primary` text, with a subtle `surface-container-high` background shift on hover.

### Cards & Lists
- **The "No-Divider" Rule:** Forbid 1px horizontal lines. Use `spacing-6` (2rem) of vertical white space to separate list items, or place each item on a `surface-container-low` rounded tile.
- **Visual Asymmetry:** In travel feeds, alternate between full-bleed imagery and inset text blocks to keep the user engaged.

### Input Fields
- Styled as "Pills." Use `surface-container-highest` for the field background. Labels should use `label-md` and sit 0.5rem above the field, never inside as placeholder text.

### Specialized Travel Components
- **Adventure Tags:** Use `tertiary_container` with `on_tertiary_container` text for "High Energy" tags; use `primary_container` for "Relaxing" tags.
- **The "Itinerary Path":** Instead of a straight line, use a soft, dashed path using `outline_variant` to connect travel waypoints, reinforcing the "adventurous" theme.

---

## 6. Do’s and Don’ts

### Do:
- **Do** use large, high-quality imagery that "breaks" the container edges.
- **Do** lean into the `spacing-8` (2.75rem) value for page margins to provide "breathing room" that feels premium.
- **Do** use `secondary` (warm orange) sparingly as an accent to draw attention to "Book" or "Save" actions.

### Don’t:
- **Don’t** use pure black (#000000) for text. Always use `on_surface` (#2c2f2e) to maintain the organic, earthy tone.
- **Don’t** use a shadow on every card. Reserve shadows for elements that physically move or float over content.
- **Don’t** use `none` roundedness. Every corner in this system must have at least a `sm` (0.5rem) radius to stay "friendly."