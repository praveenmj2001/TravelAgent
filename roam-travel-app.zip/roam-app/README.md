# 🌍 ROAM — GenZ Travel App

A visually bold, full-featured Next.js 14 travel app UI with a GenZ aesthetic.

## Stack
- **Next.js 14** (App Router)
- **React 18**
- **TypeScript**
- **Tailwind CSS**
- **Lucide React** (icons)
- **Custom CSS animations** (no heavy deps)

## Design
- 🖤 Dark void theme with electric lime `#c8f135` accents
- 🔤 Bebas Neue display font + Outfit body font
- ✨ Custom cursor, grain overlay, ambient glow orbs
- 🎞️ Staggered entrance animations, floating elements, marquee ticker

## Features
- **Hero** — Tabbed search (Flights / Hotels / Experiences / Road Trips)
- **AI Trip Planner** — Chat UI with quick prompts, itinerary builder, budget breakdown
- **Destinations** — Filterable card grid with like/bookmark, hover effects
- **Community Feed** — Social posts with likes, comments, tags
- **Auth Modal** — Login / Sign up / Forgot password with social login options
- **Custom cursor** with blend-mode difference effect
- **Sticky navbar** with mobile menu

## Quick Start

```bash
cd roam-app
npm install
npm run dev
```

Then open [http://localhost:3000](http://localhost:3000)

## Project Structure
```
roam-app/
├── app/
│   ├── globals.css       # Design tokens, animations, custom styles
│   ├── layout.tsx        # Root layout
│   └── page.tsx          # Main page (assembles all sections)
├── components/
│   ├── Cursor.tsx        # Custom animated cursor
│   ├── Navbar.tsx        # Sticky top nav
│   ├── Hero.tsx          # Hero section + search widget
│   ├── Marquee.tsx       # Destination ticker
│   ├── TripPlanner.tsx   # AI chat + itinerary panel
│   ├── Destinations.tsx  # Filterable destination cards
│   ├── Community.tsx     # Social community posts
│   ├── AuthModal.tsx     # Login/Signup modal
│   └── CTAFooter.tsx     # CTA section + footer
└── tailwind.config.js
```
