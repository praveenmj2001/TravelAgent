import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'ROAM — Travel Like You Mean It',
  description: 'The Gen Z travel app for real explorers',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="noise mesh-bg min-h-screen">
        {children}
      </body>
    </html>
  )
}
