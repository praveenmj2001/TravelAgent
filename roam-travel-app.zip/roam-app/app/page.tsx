'use client'
import { useState } from 'react'
import Cursor from '@/components/Cursor'
import Navbar from '@/components/Navbar'
import Hero from '@/components/Hero'
import MarqueeTicker from '@/components/Marquee'
import Destinations from '@/components/Destinations'
import TripPlanner from '@/components/TripPlanner'
import Community from '@/components/Community'
import CTAFooter from '@/components/CTAFooter'
import AuthModal from '@/components/AuthModal'

export default function Home() {
  const [showAuth, setShowAuth] = useState(false)

  return (
    <>
      <Cursor />
      <Navbar />
      <main>
        <Hero />
        <MarqueeTicker />

        {/* Section label: AI Trip Planner */}
        <div className="px-4 pt-16 pb-2 max-w-7xl mx-auto">
          <p className="text-xs font-semibold tracking-[0.2em] uppercase" style={{ color: 'var(--lime)' }}>AI Trip Planner</p>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(40px, 6vw, 72px)', lineHeight: 1, letterSpacing: '0.02em' }}>
            PLAN IN SECONDS
          </h2>
        </div>
        <TripPlanner />

        <Destinations />
        <Community />
        <CTAFooter onSignup={() => setShowAuth(true)} />
      </main>

      {showAuth && <AuthModal onClose={() => setShowAuth(false)} />}
    </>
  )
}
