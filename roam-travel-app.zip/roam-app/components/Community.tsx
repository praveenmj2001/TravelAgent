'use client'
import { useState } from 'react'
import { Heart, MessageCircle, Share2, Bookmark } from 'lucide-react'

const POSTS = [
  {
    id: 1, user: 'maya.wanders', handle: '@maya.wanders', avatar: 'MW',
    avatarBg: '#7c3aed',
    location: 'Amalfi Coast, 🇮🇹', time: '2h ago',
    caption: 'no thoughts just this view. dropped my planner in the sea and honestly? best decision. pure chaos mode 🌊',
    tags: ['#AmalfiCoast', '#TravelCore', '#GirlsWhoTravel'],
    likes: 4821, comments: 312,
    emoji: '🌊', bg: 'linear-gradient(135deg, #0f3460 0%, #16213e 100%)',
  },
  {
    id: 2, user: 'jakefromearth', handle: '@jakefromearth', avatar: 'JF',
    avatarBg: '#059669',
    location: 'Kyoto, 🇯🇵', time: '6h ago',
    caption: 'woke up at 4am to beat the crowds at fushimi inari and it was worth EVERY second. the quiet hits different 🦊',
    tags: ['#Japan', '#FushimiInari', '#SoloTravel'],
    likes: 7204, comments: 489,
    emoji: '🦊', bg: 'linear-gradient(135deg, #4a1942 0%, #1a0a1f 100%)',
  },
  {
    id: 3, user: 'zoe.somewhere', handle: '@zoe.somewhere', avatar: 'ZS',
    avatarBg: '#dc2626',
    location: 'Marrakech, 🇲🇦', time: '1d ago',
    caption: 'got completely lost in the medina and a random family invited me for mint tea. this is why I travel 🍵✨',
    tags: ['#Morocco', '#Marrakech', '#SerendipityTravel'],
    likes: 3156, comments: 228,
    emoji: '🍵', bg: 'linear-gradient(135deg, #78350f 0%, #1c0a00 100%)',
  },
]

export default function Community() {
  const [liked, setLiked] = useState<number[]>([2])
  const [saved, setSaved] = useState<number[]>([1])

  return (
    <section className="px-4 py-20 max-w-7xl mx-auto">
      <div className="text-center mb-12">
        <p className="text-xs font-semibold tracking-[0.2em] uppercase mb-3" style={{ color: 'var(--lime)' }}>Community</p>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(40px, 6vw, 72px)', lineHeight: 1, letterSpacing: '0.02em' }}>
          REAL TRIPS, REAL PEOPLE
        </h2>
        <p className="mt-4 text-sm max-w-md mx-auto" style={{ color: 'var(--muted)' }}>
          No influencer bs. Just real travelers sharing the actual vibe.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {POSTS.map(post => (
          <div key={post.id} className="rounded-2xl overflow-hidden dest-card"
            style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            {/* Visual */}
            <div className="h-44 flex items-center justify-center relative" style={{ background: post.bg }}>
              <div className="absolute inset-0 opacity-20" style={{ background: 'radial-gradient(circle at 30% 40%, white 0%, transparent 60%)' }} />
              <span className="text-6xl">{post.emoji}</span>
              <div className="absolute bottom-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs"
                style={{ background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)', color: 'rgba(255,255,255,0.8)' }}>
                📍 {post.location}
              </div>
            </div>

            {/* Content */}
            <div className="p-4">
              {/* User */}
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold"
                  style={{ background: post.avatarBg, color: '#fff' }}>
                  {post.avatar}
                </div>
                <div>
                  <p className="text-sm font-semibold">{post.user}</p>
                  <p className="text-xs" style={{ color: 'var(--muted)' }}>{post.time}</p>
                </div>
              </div>

              {/* Caption */}
              <p className="text-sm leading-relaxed mb-3" style={{ color: 'rgba(240,240,255,0.85)' }}>{post.caption}</p>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5 mb-4">
                {post.tags.map(tag => (
                  <span key={tag} className="text-xs px-2 py-0.5 rounded-full"
                    style={{ background: 'rgba(200,241,53,0.08)', color: 'var(--lime)', border: '1px solid rgba(200,241,53,0.15)' }}>
                    {tag}
                  </span>
                ))}
              </div>

              {/* Actions */}
              <div className="flex items-center gap-4 pt-3" style={{ borderTop: '1px solid var(--border)' }}>
                <button onClick={() => setLiked(l => l.includes(post.id) ? l.filter(x => x !== post.id) : [...l, post.id])}
                  className="flex items-center gap-1.5 text-xs transition-colors"
                  style={{ color: liked.includes(post.id) ? '#fb7185' : 'var(--muted)' }}>
                  <Heart size={15} fill={liked.includes(post.id) ? '#fb7185' : 'none'} />
                  {(post.likes + (liked.includes(post.id) ? 1 : 0)).toLocaleString()}
                </button>
                <button className="flex items-center gap-1.5 text-xs" style={{ color: 'var(--muted)' }}>
                  <MessageCircle size={15} /> {post.comments}
                </button>
                <button onClick={() => setSaved(s => s.includes(post.id) ? s.filter(x => x !== post.id) : [...s, post.id])}
                  className="ml-auto transition-colors"
                  style={{ color: saved.includes(post.id) ? 'var(--lime)' : 'var(--muted)' }}>
                  <Bookmark size={15} fill={saved.includes(post.id) ? 'var(--lime)' : 'none'} />
                </button>
                <button style={{ color: 'var(--muted)' }}><Share2 size={15} /></button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
