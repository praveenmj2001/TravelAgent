'use client'
import { useState } from 'react'
import { Heart, ArrowUpRight, Star, Flame } from 'lucide-react'

const CATEGORIES = ['All', 'Trending 🔥', 'Beaches', 'Mountains', 'Cities', 'Hidden Gems']

const DESTINATIONS = [
  {
    id: 1, name: 'Amalfi Coast', country: 'Italy', emoji: '🇮🇹',
    tag: 'Trending 🔥', hot: true,
    price: 'from $890', rating: '4.9', reviews: '12.4k',
    vibe: 'Coastal Glam',
    color: '#1a1a2e',
    gradient: 'linear-gradient(135deg, #0f3460 0%, #16213e 100%)',
    accent: '#e94560',
  },
  {
    id: 2, name: 'Bali', country: 'Indonesia', emoji: '🇮🇩',
    tag: 'Beaches', hot: false,
    price: 'from $650', rating: '4.8', reviews: '28.1k',
    vibe: 'Tropical Zen',
    color: '#0d1f0d',
    gradient: 'linear-gradient(135deg, #134e4a 0%, #052e16 100%)',
    accent: '#4ade80',
  },
  {
    id: 3, name: 'Kyoto', country: 'Japan', emoji: '🇯🇵',
    tag: 'Hidden Gems', hot: true,
    price: 'from $1,100', rating: '5.0', reviews: '8.7k',
    vibe: 'Wabi-Sabi',
    color: '#1f0d2e',
    gradient: 'linear-gradient(135deg, #4a1942 0%, #1a0a1f 100%)',
    accent: '#e879f9',
  },
  {
    id: 4, name: 'Patagonia', country: 'Argentina', emoji: '🇦🇷',
    tag: 'Mountains', hot: false,
    price: 'from $1,400', rating: '4.9', reviews: '5.2k',
    vibe: 'Wild Edge',
    color: '#0a1a2e',
    gradient: 'linear-gradient(135deg, #0c2340 0%, #071018 100%)',
    accent: '#38bdf8',
  },
  {
    id: 5, name: 'Marrakech', country: 'Morocco', emoji: '🇲🇦',
    tag: 'Hidden Gems', hot: true,
    price: 'from $540', rating: '4.7', reviews: '9.8k',
    vibe: 'Sensory Overload',
    color: '#2e1a0a',
    gradient: 'linear-gradient(135deg, #78350f 0%, #1c0a00 100%)',
    accent: '#fb923c',
  },
  {
    id: 6, name: 'Santorini', country: 'Greece', emoji: '🇬🇷',
    tag: 'Trending 🔥', hot: false,
    price: 'from $970', rating: '4.8', reviews: '31.5k',
    vibe: 'Aegean Dream',
    color: '#0a1020',
    gradient: 'linear-gradient(135deg, #1e3a5f 0%, #0a0f20 100%)',
    accent: '#93c5fd',
  },
]

export default function Destinations() {
  const [cat, setCat] = useState('All')
  const [liked, setLiked] = useState<number[]>([1, 3])

  const filtered = cat === 'All' ? DESTINATIONS : DESTINATIONS.filter(d => d.tag === cat)

  return (
    <section className="px-4 py-20 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
        <div>
          <p className="text-xs font-semibold tracking-[0.2em] uppercase mb-2" style={{ color: 'var(--lime)' }}>Drop Pins</p>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(40px, 6vw, 72px)', lineHeight: 1, letterSpacing: '0.02em' }}>
            HOT DESTINATIONS
          </h2>
        </div>
        <a href="#" className="hidden md:flex items-center gap-2 text-sm font-medium transition-colors"
          style={{ color: 'var(--muted)' }}
          onMouseEnter={e => (e.currentTarget.style.color = 'var(--lime)')}
          onMouseLeave={e => (e.currentTarget.style.color = 'var(--muted)')}>
          View all <ArrowUpRight size={14} />
        </a>
      </div>

      {/* Category pills */}
      <div className="flex gap-2 mb-8 overflow-x-auto pb-2 scrollbar-hide">
        {CATEGORIES.map(c => (
          <button key={c} onClick={() => setCat(c)}
            className="flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-all duration-200"
            style={cat === c
              ? { background: 'var(--lime)', color: 'var(--void)', fontWeight: 600 }
              : { background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--muted)' }}>
            {c}
          </button>
        ))}
      </div>

      {/* Cards grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((dest, i) => (
          <div key={dest.id}
            className="dest-card rounded-2xl overflow-hidden cursor-pointer group relative"
            style={{ background: dest.gradient, border: '1px solid rgba(255,255,255,0.06)', minHeight: '320px', animationDelay: `${i * 0.07}s` }}>

            {/* Map/Visual area */}
            <div className="relative h-48 overflow-hidden flex items-center justify-center"
              style={{ background: dest.gradient }}>
              {/* Decorative circles */}
              <div className="absolute w-40 h-40 rounded-full opacity-20"
                style={{ background: dest.accent, filter: 'blur(40px)', top: '10%', left: '20%' }} />
              <div className="absolute w-24 h-24 rounded-full opacity-15"
                style={{ background: dest.accent, filter: 'blur(30px)', bottom: '10%', right: '15%' }} />

              {/* Flag + emoji giant */}
              <div className="text-7xl relative z-10 group-hover:scale-110 transition-transform duration-500 select-none">
                {dest.emoji}
              </div>

              {/* Hot badge */}
              {dest.hot && (
                <div className="absolute top-3 left-3 flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold"
                  style={{ background: 'rgba(251,146,60,0.2)', border: '1px solid rgba(251,146,60,0.4)', color: '#fb923c' }}>
                  <Flame size={11} /> Hot
                </div>
              )}

              {/* Like button */}
              <button
                onClick={e => { e.stopPropagation(); setLiked(l => l.includes(dest.id) ? l.filter(x => x !== dest.id) : [...l, dest.id]) }}
                className="absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center transition-all duration-200"
                style={{ background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(8px)' }}>
                <Heart size={14} fill={liked.includes(dest.id) ? '#c8f135' : 'none'} color={liked.includes(dest.id) ? '#c8f135' : '#fff'} />
              </button>

              {/* Vibe chip */}
              <div className="absolute bottom-3 left-3 px-3 py-1 rounded-full text-xs font-medium"
                style={{ background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)', color: dest.accent, border: `1px solid ${dest.accent}40` }}>
                {dest.vibe}
              </div>
            </div>

            {/* Info */}
            <div className="p-4">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h3 className="text-lg font-bold" style={{ color: 'var(--text)' }}>{dest.name}</h3>
                  <p className="text-xs" style={{ color: 'var(--muted)' }}>{dest.country}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold" style={{ color: 'var(--lime)' }}>{dest.price}</p>
                  <div className="flex items-center gap-1 justify-end">
                    <Star size={11} fill="#c8f135" color="#c8f135" />
                    <span className="text-xs" style={{ color: 'var(--muted)' }}>{dest.rating} ({dest.reviews})</span>
                  </div>
                </div>
              </div>

              <button className="w-full mt-2 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200 flex items-center justify-center gap-2 group/btn"
                style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: 'var(--text)' }}
                onMouseEnter={e => { (e.currentTarget.style.background = 'var(--lime)'); (e.currentTarget.style.color = 'var(--void)') }}
                onMouseLeave={e => { (e.currentTarget.style.background = 'rgba(255,255,255,0.06)'); (e.currentTarget.style.color = 'var(--text)') }}>
                Explore <ArrowUpRight size={14} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
