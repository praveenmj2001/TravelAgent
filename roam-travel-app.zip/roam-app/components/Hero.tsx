'use client'
import { useState } from 'react'
import { Search, MapPin, Calendar, Users, ArrowRight, Sparkles } from 'lucide-react'

const TABS = ['Flights', 'Hotels', 'Experiences', 'Road Trips']

export default function Hero() {
  const [activeTab, setActiveTab] = useState('Flights')
  const [searchFocused, setSearchFocused] = useState(false)

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center pt-20 px-4 overflow-hidden">
      {/* Background orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(200,241,53,0.06) 0%, transparent 70%)', filter: 'blur(40px)', animation: 'float 8s ease-in-out infinite' }} />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(120,80,255,0.08) 0%, transparent 70%)', filter: 'blur(50px)', animation: 'float 10s ease-in-out infinite reverse' }} />

      <div className="relative z-10 w-full max-w-5xl mx-auto text-center stagger">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-8 text-xs font-medium tracking-widest uppercase"
          style={{ background: 'var(--lime-dim)', border: '1px solid rgba(200,241,53,0.2)', color: 'var(--lime)' }}>
          <Sparkles size={12} />
          AI-Powered Travel Planning · No cap fr
        </div>

        {/* Headline */}
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(72px, 14vw, 160px)', lineHeight: 0.9, letterSpacing: '-0.02em' }}
          className="mb-6 text-glow">
          <span style={{ color: 'var(--text)' }}>GO</span>
          <br />
          <span style={{ color: 'var(--lime)', WebkitTextStroke: '0px', display: 'inline-block' }}>ANYWHERE</span>
          <br />
          <span style={{ color: 'var(--text)', WebkitTextStroke: '1px rgba(255,255,255,0.3)', WebkitTextFillColor: 'transparent' }}>NOW</span>
        </h1>

        <p className="max-w-xl mx-auto mb-10 font-light leading-relaxed" style={{ color: 'var(--muted)', fontSize: '16px' }}>
          Drop pins, not plans. Discover bucket-list destinations, book in seconds, and connect with travelers who get it.
        </p>

        {/* Search widget */}
        <div className="rounded-2xl overflow-hidden mx-auto max-w-3xl"
          style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: '0 32px 80px rgba(0,0,0,0.5)' }}>

          {/* Tabs */}
          <div className="flex p-2 gap-1" style={{ borderBottom: '1px solid var(--border)' }}>
            {TABS.map(tab => (
              <button key={tab}
                onClick={() => setActiveTab(tab)}
                className="flex-1 py-2.5 px-3 rounded-xl text-sm font-medium transition-all duration-200"
                style={activeTab === tab
                  ? { background: 'var(--lime)', color: 'var(--void)', fontWeight: 600 }
                  : { color: 'var(--muted)' }}>
                {tab}
              </button>
            ))}
          </div>

          {/* Inputs */}
          <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="md:col-span-1 relative">
              <MapPin size={16} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--lime)' }} />
              <input className="input-field pl-9" placeholder="Where to?" style={{ fontSize: '14px' }} />
            </div>
            <div className="relative">
              <Calendar size={16} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--muted)' }} />
              <input className="input-field pl-9" type="text" placeholder="When?" style={{ fontSize: '14px' }} />
            </div>
            <div className="relative">
              <Users size={16} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--muted)' }} />
              <input className="input-field pl-9" placeholder="Who's coming?" style={{ fontSize: '14px' }} />
            </div>
          </div>

          {/* CTA */}
          <div className="px-4 pb-4">
            <button className="w-full py-4 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all duration-200 group"
              style={{ background: 'var(--lime)', color: 'var(--void)', fontSize: '15px', letterSpacing: '0.02em' }}
              onMouseEnter={e => { (e.currentTarget.style.boxShadow = '0 0 40px rgba(200,241,53,0.4)'); (e.currentTarget.style.transform = 'scale(1.01)') }}
              onMouseLeave={e => { (e.currentTarget.style.boxShadow = ''); (e.currentTarget.style.transform = '') }}>
              <Search size={18} />
              Search Trips
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>

        {/* Stats row */}
        <div className="flex items-center justify-center gap-8 mt-8 text-sm" style={{ color: 'var(--muted)' }}>
          {[['2.4M+', 'Travelers'], ['190+', 'Countries'], ['4.9★', 'App Rating']].map(([num, label]) => (
            <div key={label} className="text-center">
              <div className="font-bold text-base" style={{ color: 'var(--text)' }}>{num}</div>
              <div className="text-xs tracking-wide">{label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
