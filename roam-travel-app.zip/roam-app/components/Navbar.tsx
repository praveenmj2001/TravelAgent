'use client'
import { useState } from 'react'
import { Compass, Bell, Search, Menu, X } from 'lucide-react'

export default function Navbar() {
  const [open, setOpen] = useState(false)

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-4"
      style={{ background: 'rgba(8,8,16,0.7)', backdropFilter: 'blur(20px)', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
      {/* Logo */}
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'var(--lime)' }}>
          <Compass size={18} color="#080810" strokeWidth={2.5} />
        </div>
        <span style={{ fontFamily: 'var(--font-display)', fontSize: '22px', letterSpacing: '0.08em', color: 'var(--lime)' }}>
          ROAM
        </span>
      </div>

      {/* Nav links */}
      <div className="hidden md:flex items-center gap-8">
        {['Explore', 'Trips', 'Community', 'Deals'].map(link => (
          <a key={link} href="#" className="text-sm font-medium transition-colors"
            style={{ color: 'var(--muted)', letterSpacing: '0.02em' }}
            onMouseEnter={e => (e.currentTarget.style.color = 'var(--lime)')}
            onMouseLeave={e => (e.currentTarget.style.color = 'var(--muted)')}>
            {link}
          </a>
        ))}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-3">
        <button className="hidden md:flex w-9 h-9 rounded-full items-center justify-center transition-colors"
          style={{ border: '1px solid var(--border)' }}
          onMouseEnter={e => { (e.currentTarget.style.borderColor = 'var(--lime)'); (e.currentTarget.style.background = 'var(--lime-dim)') }}
          onMouseLeave={e => { (e.currentTarget.style.borderColor = 'var(--border)'); (e.currentTarget.style.background = 'transparent') }}>
          <Search size={16} color="var(--muted)" />
        </button>

        <button className="relative w-9 h-9 rounded-full flex items-center justify-center"
          style={{ border: '1px solid var(--border)' }}>
          <Bell size={16} color="var(--muted)" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full" style={{ background: 'var(--lime)' }} />
        </button>

        <div className="w-8 h-8 rounded-full overflow-hidden" style={{ border: '2px solid var(--lime)' }}>
          <div className="w-full h-full flex items-center justify-center text-xs font-bold"
            style={{ background: 'var(--lime)', color: 'var(--void)' }}>JL</div>
        </div>

        <button className="md:hidden" onClick={() => setOpen(!open)}>
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="absolute top-full left-0 right-0 p-6 flex flex-col gap-4 md:hidden"
          style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border)' }}>
          {['Explore', 'Trips', 'Community', 'Deals'].map(link => (
            <a key={link} href="#" className="text-base font-medium" style={{ color: 'var(--muted)' }}>{link}</a>
          ))}
        </div>
      )}
    </nav>
  )
}
