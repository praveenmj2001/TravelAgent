'use client'
import { Compass, Instagram, Twitter, Github } from 'lucide-react'

interface CTAProps {
  onSignup: () => void
}

export default function CTAFooter({ onSignup }: CTAProps) {
  return (
    <>
      {/* CTA Section */}
      <section className="px-4 py-24 max-w-4xl mx-auto text-center">
        <div className="rounded-3xl p-12 relative overflow-hidden"
          style={{ background: 'var(--card)', border: '1px solid rgba(200,241,53,0.15)' }}>
          <div className="absolute inset-0 pointer-events-none"
            style={{ background: 'radial-gradient(ellipse 70% 60% at 50% 0%, rgba(200,241,53,0.08) 0%, transparent 70%)' }} />
          <div className="relative z-10">
            <p className="text-xs font-semibold tracking-[0.2em] uppercase mb-4" style={{ color: 'var(--lime)' }}>Free forever</p>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(44px, 8vw, 88px)', lineHeight: 1, letterSpacing: '0.02em' }} className="mb-6">
              YOUR NEXT TRIP<br />STARTS NOW
            </h2>
            <p className="mb-8 max-w-md mx-auto text-sm" style={{ color: 'var(--muted)' }}>
              Join 2.4 million travelers who stopped dreaming and started going.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <button onClick={onSignup}
                className="px-8 py-4 rounded-xl font-semibold text-sm transition-all glow-lime"
                style={{ background: 'var(--lime)', color: 'var(--void)' }}
                onMouseEnter={e => (e.currentTarget.style.transform = 'scale(1.03)')}
                onMouseLeave={e => (e.currentTarget.style.transform = '')}>
                Create Free Account ✈️
              </button>
              <button className="px-8 py-4 rounded-xl font-semibold text-sm transition-all"
                style={{ border: '1px solid rgba(255,255,255,0.15)', color: 'var(--text)' }}
                onMouseEnter={e => (e.currentTarget.style.borderColor = 'var(--lime)')}
                onMouseLeave={e => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.15)')}>
                Watch Demo
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-6 py-10" style={{ borderTop: '1px solid var(--border)' }}>
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: 'var(--lime)' }}>
              <Compass size={15} color="var(--void)" />
            </div>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: '18px', color: 'var(--lime)', letterSpacing: '0.08em' }}>ROAM</span>
          </div>
          <p className="text-xs text-center" style={{ color: 'var(--muted)' }}>
            © 2025 ROAM Inc. · Made for the explorers, the wanderers, the ones who just go.
          </p>
          <div className="flex items-center gap-4">
            {[Instagram, Twitter, Github].map((Icon, i) => (
              <button key={i} className="w-8 h-8 rounded-full flex items-center justify-center transition-all"
                style={{ border: '1px solid var(--border)' }}
                onMouseEnter={e => { (e.currentTarget.style.borderColor = 'var(--lime)'); (e.currentTarget.style.background = 'var(--lime-dim)') }}
                onMouseLeave={e => { (e.currentTarget.style.borderColor = 'var(--border)'); (e.currentTarget.style.background = 'transparent') }}>
                <Icon size={14} style={{ color: 'var(--muted)' }} />
              </button>
            ))}
          </div>
        </div>
      </footer>
    </>
  )
}
