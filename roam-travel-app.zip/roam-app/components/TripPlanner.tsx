'use client'
import { useState } from 'react'
import { Send, Bot, Sparkles, User, MapPin, Clock, DollarSign } from 'lucide-react'

const QUICK_PROMPTS = [
  '7 days in Southeast Asia under $1500',
  'Solo trip to Japan in spring',
  'Honeymoon in the Maldives',
  'Adventure trip in South America',
]

const SAMPLE_CONVO = [
  {
    role: 'ai',
    text: "Hey! I'm your ROAM AI travel buddy 🌍 Tell me your dream trip — budget, vibe, dates — and I'll plan the whole thing.",
  },
]

const AI_RESPONSE = {
  text: "Yesss, Southeast Asia in 7 days for under $1500 is totally doable! Here's your vibe check:",
  itinerary: [
    { day: '1-2', place: 'Bangkok, Thailand', note: 'Street food, temples, rooftop bars', icon: '🇹🇭' },
    { day: '3-4', place: 'Chiang Mai', note: 'Elephant sanctuaries, night markets', icon: '🐘' },
    { day: '5-6', place: 'Bali, Indonesia', note: 'Rice terraces, surf, sunset pura', icon: '🌺' },
    { day: '7', place: 'Seminyak Beach', note: 'Final day beach day, you earned it', icon: '🏖️' },
  ],
  budget: { flights: '$420', stays: '$490', food: '$210', activities: '$180' },
}

export default function TripPlanner() {
  const [messages, setMessages] = useState(SAMPLE_CONVO)
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [showItinerary, setShowItinerary] = useState(false)

  const send = (text?: string) => {
    const msg = text || input
    if (!msg.trim()) return
    setMessages(m => [...m, { role: 'user', text: msg }])
    setInput('')
    setLoading(true)
    setTimeout(() => {
      setMessages(m => [...m, { role: 'ai', text: AI_RESPONSE.text }])
      setLoading(false)
      setShowItinerary(true)
    }, 1400)
  }

  return (
    <section className="px-4 py-20 max-w-7xl mx-auto">
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Chat panel */}
        <div className="flex-1 rounded-2xl overflow-hidden flex flex-col"
          style={{ background: 'var(--card)', border: '1px solid var(--border)', minHeight: '560px' }}>

          {/* Chat header */}
          <div className="flex items-center gap-3 px-5 py-4" style={{ borderBottom: '1px solid var(--border)' }}>
            <div className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: 'var(--lime)' }}>
              <Bot size={18} color="var(--void)" />
            </div>
            <div>
              <p className="font-semibold text-sm">ROAM AI</p>
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: '#4ade80' }} />
                <span className="text-xs" style={{ color: 'var(--muted)' }}>Online · always down to plan</span>
              </div>
            </div>
            <Sparkles size={16} className="ml-auto" style={{ color: 'var(--lime)' }} />
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-5 flex flex-col gap-4" style={{ maxHeight: '320px' }}>
            {messages.map((msg, i) => (
              <div key={i} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                <div className="w-7 h-7 rounded-full flex-shrink-0 flex items-center justify-center"
                  style={{ background: msg.role === 'ai' ? 'var(--lime)' : 'rgba(255,255,255,0.1)' }}>
                  {msg.role === 'ai' ? <Bot size={14} color="var(--void)" /> : <User size={14} />}
                </div>
                <div className="max-w-[80%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed"
                  style={msg.role === 'ai'
                    ? { background: 'rgba(255,255,255,0.05)', color: 'var(--text)', borderRadius: '4px 18px 18px 18px' }
                    : { background: 'var(--lime)', color: 'var(--void)', fontWeight: 500, borderRadius: '18px 4px 18px 18px' }}>
                  {msg.text}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex gap-3">
                <div className="w-7 h-7 rounded-full flex items-center justify-center" style={{ background: 'var(--lime)' }}>
                  <Bot size={14} color="var(--void)" />
                </div>
                <div className="px-4 py-3 rounded-2xl" style={{ background: 'rgba(255,255,255,0.05)', borderRadius: '4px 18px 18px 18px' }}>
                  <div className="flex gap-1.5">
                    {[0,1,2].map(i => (
                      <span key={i} className="w-2 h-2 rounded-full" style={{ background: 'var(--lime)', animation: `float 1s ease-in-out ${i * 0.2}s infinite` }} />
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Quick prompts */}
          <div className="px-5 pb-3 flex gap-2 overflow-x-auto">
            {QUICK_PROMPTS.map(p => (
              <button key={p} onClick={() => send(p)}
                className="flex-shrink-0 px-3 py-1.5 rounded-full text-xs transition-all"
                style={{ background: 'rgba(200,241,53,0.08)', border: '1px solid rgba(200,241,53,0.2)', color: 'var(--lime)', whiteSpace: 'nowrap' }}>
                {p}
              </button>
            ))}
          </div>

          {/* Input */}
          <div className="p-4 pt-0 flex gap-2">
            <input className="input-field flex-1 text-sm" style={{ borderRadius: '12px' }}
              placeholder="Describe your dream trip..." value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && send()} />
            <button onClick={() => send()}
              className="w-11 h-11 rounded-xl flex items-center justify-center transition-all"
              style={{ background: 'var(--lime)', flexShrink: 0 }}
              onMouseEnter={e => (e.currentTarget.style.boxShadow = '0 0 20px rgba(200,241,53,0.4)')}
              onMouseLeave={e => (e.currentTarget.style.boxShadow = '')}>
              <Send size={16} color="var(--void)" />
            </button>
          </div>
        </div>

        {/* Itinerary panel */}
        <div className="lg:w-80 rounded-2xl overflow-hidden flex flex-col gap-4">
          {showItinerary ? (
            <>
              {/* Itinerary */}
              <div className="rounded-2xl p-5" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                <div className="flex items-center gap-2 mb-4">
                  <MapPin size={15} style={{ color: 'var(--lime)' }} />
                  <p className="font-semibold text-sm">AI Itinerary</p>
                  <span className="ml-auto px-2 py-0.5 rounded text-xs" style={{ background: 'var(--lime-dim)', color: 'var(--lime)' }}>7 days</span>
                </div>
                <div className="flex flex-col gap-3">
                  {AI_RESPONSE.itinerary.map((item, i) => (
                    <div key={i} className="flex gap-3 items-start">
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 text-base"
                        style={{ background: 'rgba(255,255,255,0.05)' }}>{item.icon}</div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium">{item.place}</p>
                        </div>
                        <p className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>{item.note}</p>
                      </div>
                      <span className="text-xs flex-shrink-0 mt-0.5" style={{ color: 'var(--lime)' }}>D{item.day}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Budget breakdown */}
              <div className="rounded-2xl p-5" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                <div className="flex items-center gap-2 mb-4">
                  <DollarSign size={15} style={{ color: 'var(--lime)' }} />
                  <p className="font-semibold text-sm">Budget Breakdown</p>
                </div>
                {Object.entries(AI_RESPONSE.budget).map(([k, v]) => (
                  <div key={k} className="flex justify-between py-2" style={{ borderBottom: '1px solid var(--border)' }}>
                    <span className="text-sm capitalize" style={{ color: 'var(--muted)' }}>{k}</span>
                    <span className="text-sm font-semibold">{v}</span>
                  </div>
                ))}
                <div className="flex justify-between pt-3 mt-1">
                  <span className="text-sm font-bold">Total</span>
                  <span className="font-bold" style={{ color: 'var(--lime)' }}>$1,300</span>
                </div>
              </div>
            </>
          ) : (
            <div className="rounded-2xl p-8 flex flex-col items-center justify-center text-center flex-1"
              style={{ background: 'var(--card)', border: '1px dashed var(--border)', minHeight: '300px' }}>
              <div className="text-4xl mb-3">🗺️</div>
              <p className="font-semibold mb-1">Your itinerary</p>
              <p className="text-sm" style={{ color: 'var(--muted)' }}>Chat with ROAM AI to generate your personalized trip plan</p>
            </div>
          )}

          {showItinerary && (
            <button className="w-full py-3 rounded-xl font-semibold text-sm transition-all"
              style={{ background: 'var(--lime)', color: 'var(--void)' }}
              onMouseEnter={e => (e.currentTarget.style.boxShadow = '0 0 30px rgba(200,241,53,0.3)')}
              onMouseLeave={e => (e.currentTarget.style.boxShadow = '')}>
              Book This Trip ✈️
            </button>
          )}
        </div>
      </div>
    </section>
  )
}
