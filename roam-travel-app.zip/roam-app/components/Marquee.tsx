const items = [
  '🏔️ Patagonia', '🌊 Maldives', '🏙️ Tokyo', '🌴 Bali', '🗽 New York',
  '🏛️ Athens', '🌸 Kyoto', '🏜️ Sahara', '🦁 Serengeti', '🏔️ Nepal',
  '🎭 Paris', '🌋 Iceland', '🎪 Barcelona', '🏝️ Santorini', '🌿 Amazon',
  '🏔️ Patagonia', '🌊 Maldives', '🏙️ Tokyo', '🌴 Bali', '🗽 New York',
  '🏛️ Athens', '🌸 Kyoto', '🏜️ Sahara', '🦁 Serengeti', '🏔️ Nepal',
  '🎭 Paris', '🌋 Iceland', '🎪 Barcelona', '🏝️ Santorini', '🌿 Amazon',
]

export default function Marquee() {
  return (
    <div className="w-full overflow-hidden py-5" style={{ borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)', background: 'var(--surface)' }}>
      <div className="marquee-track">
        {items.map((item, i) => (
          <span key={i} className="mx-8 text-sm font-medium tracking-wide flex-shrink-0"
            style={{ color: i % 5 === 0 ? 'var(--lime)' : 'var(--muted)' }}>
            {item}
          </span>
        ))}
      </div>
    </div>
  )
}
