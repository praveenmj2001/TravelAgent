'use client'
import { useState } from 'react'
import { X, Mail, Lock, User, Eye, EyeOff, ArrowRight, Compass, CheckCircle2 } from 'lucide-react'

const PERKS = ['AI trip planner', 'Save & sync itineraries', 'Join the community', 'Exclusive deals']

type Mode = 'login' | 'signup' | 'forgot'

interface AuthModalProps {
  onClose: () => void
}

export default function AuthModal({ onClose }: AuthModalProps) {
  const [mode, setMode] = useState<Mode>('login')
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)
  const [done, setDone] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', password: '' })

  const handleSubmit = () => {
    setLoading(true)
    setTimeout(() => { setLoading(false); setDone(true) }, 1800)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(8,8,16,0.85)', backdropFilter: 'blur(16px)' }}
      onClick={onClose}>
      <div className="w-full max-w-md rounded-3xl overflow-hidden relative"
        style={{ background: 'var(--card)', border: '1px solid rgba(255,255,255,0.1)', boxShadow: '0 40px 100px rgba(0,0,0,0.7)' }}
        onClick={e => e.stopPropagation()}>

        {/* Decorative header */}
        <div className="relative h-28 overflow-hidden flex items-center justify-center"
          style={{ background: 'linear-gradient(135deg, #0a1f0a 0%, #080810 100%)' }}>
          <div className="absolute w-40 h-40 rounded-full" style={{ background: 'radial-gradient(circle, rgba(200,241,53,0.15) 0%, transparent 70%)', filter: 'blur(20px)' }} />
          <div className="flex items-center gap-3 relative z-10">
            <div className="w-11 h-11 rounded-2xl flex items-center justify-center" style={{ background: 'var(--lime)' }}>
              <Compass size={22} color="var(--void)" strokeWidth={2.5} />
            </div>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: '32px', letterSpacing: '0.1em', color: 'var(--lime)' }}>ROAM</span>
          </div>
          <button onClick={onClose} className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center"
            style={{ background: 'rgba(255,255,255,0.08)' }}>
            <X size={16} />
          </button>
        </div>

        <div className="p-6">
          {done ? (
            <div className="text-center py-6">
              <CheckCircle2 size={48} className="mx-auto mb-4" style={{ color: 'var(--lime)' }} />
              <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '28px', letterSpacing: '0.05em' }}>LET'S GO! 🚀</h3>
              <p className="text-sm mt-2" style={{ color: 'var(--muted)' }}>Your account is ready. Time to explore.</p>
              <button onClick={onClose} className="mt-6 w-full py-3 rounded-xl font-semibold text-sm"
                style={{ background: 'var(--lime)', color: 'var(--void)' }}>Start Exploring</button>
            </div>
          ) : (
            <>
              {/* Mode switcher */}
              {mode !== 'forgot' && (
                <div className="flex p-1 rounded-xl mb-6" style={{ background: 'rgba(255,255,255,0.04)' }}>
                  {(['login', 'signup'] as Mode[]).map(m => (
                    <button key={m} onClick={() => setMode(m)}
                      className="flex-1 py-2 rounded-lg text-sm font-medium capitalize transition-all"
                      style={mode === m ? { background: 'var(--lime)', color: 'var(--void)', fontWeight: 600 } : { color: 'var(--muted)' }}>
                      {m === 'login' ? 'Sign in' : 'Sign up'}
                    </button>
                  ))}
                </div>
              )}

              <h2 className="font-bold text-xl mb-1">
                {mode === 'login' && 'Welcome back ✌️'}
                {mode === 'signup' && 'Join the movement 🌍'}
                {mode === 'forgot' && 'Reset your password'}
              </h2>
              <p className="text-xs mb-5" style={{ color: 'var(--muted)' }}>
                {mode === 'login' && 'Your next adventure is one tap away'}
                {mode === 'signup' && 'Free forever. No cap.'}
                {mode === 'forgot' && "We'll send a reset link to your email"}
              </p>

              {/* Perks for signup */}
              {mode === 'signup' && (
                <div className="grid grid-cols-2 gap-2 mb-5">
                  {PERKS.map(p => (
                    <div key={p} className="flex items-center gap-2 text-xs" style={{ color: 'var(--muted)' }}>
                      <span style={{ color: 'var(--lime)' }}>✓</span> {p}
                    </div>
                  ))}
                </div>
              )}

              {/* Fields */}
              <div className="flex flex-col gap-3">
                {mode === 'signup' && (
                  <div className="relative">
                    <User size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2" style={{ color: 'var(--muted)' }} />
                    <input className="input-field pl-10 text-sm" placeholder="Your name"
                      value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
                  </div>
                )}
                <div className="relative">
                  <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2" style={{ color: 'var(--muted)' }} />
                  <input className="input-field pl-10 text-sm" type="email" placeholder="Email address"
                    value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
                </div>
                {mode !== 'forgot' && (
                  <div className="relative">
                    <Lock size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2" style={{ color: 'var(--muted)' }} />
                    <input className="input-field pl-10 pr-10 text-sm" type={showPw ? 'text' : 'password'} placeholder="Password"
                      value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} />
                    <button onClick={() => setShowPw(s => !s)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2" style={{ color: 'var(--muted)' }}>
                      {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                )}
              </div>

              {mode === 'login' && (
                <button onClick={() => setMode('forgot')} className="text-xs mt-2 block text-right"
                  style={{ color: 'var(--lime)' }}>Forgot password?</button>
              )}

              <button onClick={handleSubmit}
                className="w-full mt-4 py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all"
                style={{ background: 'var(--lime)', color: 'var(--void)' }}
                onMouseEnter={e => (e.currentTarget.style.boxShadow = '0 0 30px rgba(200,241,53,0.35)')}
                onMouseLeave={e => (e.currentTarget.style.boxShadow = '')}>
                {loading ? (
                  <span className="w-5 h-5 rounded-full border-2 border-current border-t-transparent animate-spin" />
                ) : (
                  <>
                    {mode === 'login' ? 'Sign In' : mode === 'signup' ? 'Create Account' : 'Send Reset Link'}
                    <ArrowRight size={16} />
                  </>
                )}
              </button>

              {/* Social */}
              {mode !== 'forgot' && (
                <>
                  <div className="flex items-center gap-3 my-4">
                    <div className="flex-1 h-px" style={{ background: 'var(--border)' }} />
                    <span className="text-xs" style={{ color: 'var(--muted)' }}>or</span>
                    <div className="flex-1 h-px" style={{ background: 'var(--border)' }} />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {[['G', 'Google', '#ea4335'], ['A', 'Apple', '#fff']].map(([icon, label, color]) => (
                      <button key={label}
                        className="flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-medium transition-all"
                        style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid var(--border)' }}
                        onMouseEnter={e => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.2)')}
                        onMouseLeave={e => (e.currentTarget.style.borderColor = 'var(--border)')}>
                        <span style={{ color, fontWeight: 700, fontSize: '15px' }}>{icon}</span>
                        {label}
                      </button>
                    ))}
                  </div>
                </>
              )}

              {mode === 'forgot' && (
                <button onClick={() => setMode('login')} className="text-xs mt-3 block text-center w-full"
                  style={{ color: 'var(--muted)' }}>← Back to sign in</button>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}
